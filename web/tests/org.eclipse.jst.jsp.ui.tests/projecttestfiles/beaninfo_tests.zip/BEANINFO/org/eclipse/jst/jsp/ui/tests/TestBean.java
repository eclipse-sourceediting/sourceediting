package org.eclipse.jst.jsp.ui.tests;

/**
 * @author pavery
 *
 */
public class TestBean {
	public String getName() {
		return "phil";
	}
	public void setName(String name) {
		
	}
	public int getGetButNoSet() {
		return 5;
	}
	public void setSetButNoGet(int val) {
		
	}
	public void setWithNoParameter() {
		
	}
}
