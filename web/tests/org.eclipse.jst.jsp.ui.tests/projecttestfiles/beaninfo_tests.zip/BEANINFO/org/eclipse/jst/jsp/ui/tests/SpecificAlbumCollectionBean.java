package org.eclipse.jst.jsp.ui.tests;

/**
 * @author pavery
 *
 */
public class SpecificAlbumCollectionBean extends BaseAlbumCollectionBean {
	public String getOwnerName() {
		return "phil";
	}
}
