package com.ibm.test;

/**
 * Just a test class
 * 
 * @author pavery
 */
public class Jellybean2 {
	
	String foobu = null;
	
	/**
	 * does <b>foo2</b> stuff
	 */
	protected void foo2(String foo) {
		this.foobu = foo;
	}
	
	/**
	 * get some stylish clothing.
	 * @return stuff
	 * @todo Generated comment
	 */
	public String getFuBu() {
		return "fubu";
	}
	
	
}
