
/**
 * @author pavery
 */
public class Jellybean {
	/**
	 * does foo <b>stuff</b>
	 *
	 */
	public void foo() {
		
	}
	/**
	 * returns a chicken
	 * @return
	 */
	public String boo() {
		return "chicken";
	}
}
