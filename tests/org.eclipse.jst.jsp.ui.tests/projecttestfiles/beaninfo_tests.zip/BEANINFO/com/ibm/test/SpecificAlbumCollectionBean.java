package com.ibm.test;

/**
 * @author pavery
 *
 */
public class SpecificAlbumCollectionBean extends BaseAlbumCollectionBean {
	public String getOwnerName() {
		return "phil";
	}
}
