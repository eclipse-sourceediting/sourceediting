package com.ibm.test;

/**
 * @author pavery
 *
 */
public class BaseAlbumCollectionBean {
	String fOwnerName = "";
	String[] fCds = null;
	
	// simple get/set property
	public String getOwnerName() {
		return "nobody";
	}
	
	public void setOwnerName(String name) {
		fOwnerName = name;
	}
	
	// - string array property
	// - set only
	// array setter
	// array getter
	public void setCds(String[] cds) {
		fCds = cds;
	}
	
	// - string array property
	// - set and get
	// indexed property setter/setter
	public void setCd(int i, String cd) {
		fCds[i] = cd;
	}
	public String getCd(int i) {
		return fCds[i];
	}
	
	public int getNumCds() {
		return fCds.length;
	}
	
	// invalid name lengths
	// should not show up
	public int get() {
		return 0;
	}
	public int is() {
		return 0;
	}
	public void set(String s) {
	}
}
