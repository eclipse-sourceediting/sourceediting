/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * This file is part of SableCC.                             *
 * See the file "LICENSE" for copyright information and the  *
 * terms and conditions for copying, distribution and        *
 * modification of SableCC.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package org.sablecc.sablecc;

import java.util.*;
import org.sablecc.sablecc.node.*;

public class NodeComparator implements Comparator
{
    public final static NodeComparator instance = new NodeComparator();

    private NodeComparator()
    {
    }

    public int compare(Object o1, Object o2)
    {
        return ((Node) o1).getId() - ((Node) o2).getId();
    }
}

